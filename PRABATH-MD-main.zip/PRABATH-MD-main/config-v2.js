const GITHUB_AUTH_TOKEN = "null"
const BOT_NUMBER = "null"
const SESSION_ID = ""


module.exports = {
GITHUB_AUTH_TOKEN,
BOT_NUMBER,
SESSION_ID
}
